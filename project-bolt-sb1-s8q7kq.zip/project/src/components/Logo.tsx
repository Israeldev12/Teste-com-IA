import React from 'react';
import { Scissors } from 'lucide-react';

export const Logo = () => {
  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <Scissors className="w-8 h-8 text-amber-700 rotate-90" />
      </div>
      <span className="text-2xl font-serif font-bold text-amber-700">Senhor Espetto</span>
    </div>
  );
};