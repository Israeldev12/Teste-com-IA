import React from 'react';
import { Music, Beer, Users } from 'lucide-react';

export const Ambiente = () => {
  return (
    <section id="ambiente" className="py-20 bg-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-serif font-bold text-amber-500 text-center mb-16">
          Nosso Ambiente
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Feature
            icon={<Music className="w-8 h-8" />}
            title="Música ao Vivo"
            description="Jazz e MPB todas as quintas e sábados"
          />
          <Feature
            icon={<Beer className="w-8 h-8" />}
            title="Cervejas Especiais"
            description="Ampla seleção de cervejas nacionais e importadas"
          />
          <Feature
            icon={<Users className="w-8 h-8" />}
            title="Ambiente Acolhedor"
            description="Espaço ideal para encontros e comemorações"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <img
            src="https://images.unsplash.com/photo-1470337458703-46ad1756a187?auto=format&fit=crop&q=80"
            alt="Ambiente do bar"
            className="rounded-lg"
          />
          <img
            src="https://images.unsplash.com/photo-1525268323446-0505b6fe7778?auto=format&fit=crop&q=80"
            alt="Área externa"
            className="rounded-lg"
          />
        </div>
      </div>
    </section>
  );
};

const Feature = ({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) => (
  <div className="text-center">
    <div className="inline-block p-4 bg-amber-500 rounded-full mb-4">
      <div className="text-stone-900">{icon}</div>
    </div>
    <h3 className="text-xl font-semibold text-amber-500 mb-2">{title}</h3>
    <p className="text-stone-300">{description}</p>
  </div>
);