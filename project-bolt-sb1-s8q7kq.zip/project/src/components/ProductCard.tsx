import React from 'react';

interface ProductCardProps {
  name: string;
  image: string;
  description: string;
  details: string[];
}

export const ProductCard = ({ name, image, description, details }: ProductCardProps) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <img src={image} alt={name} className="w-full h-64 object-cover" />
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">{name}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <div className="space-y-2">
          {details.map((detail, index) => (
            <p key={index} className="text-sm text-gray-500 flex items-center">
              <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
              {detail}
            </p>
          ))}
        </div>
      </div>
    </div>
  );
};