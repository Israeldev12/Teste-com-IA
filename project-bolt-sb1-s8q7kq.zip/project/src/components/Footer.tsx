import React from 'react';
import { Instagram, Facebook, MapPin, Phone, Mail } from 'lucide-react';
import { Logo } from './Logo';

export const Footer = () => {
  return (
    <footer className="bg-stone-900 text-stone-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <Logo />
            <p className="mt-4">O melhor bar de espetos da cidade, com ambiente acolhedor e música ao vivo.</p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-amber-500 mb-4">Contato</h3>
            <div className="space-y-3">
              <p className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-amber-500" />
                (11) 99999-9999
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-amber-500" />
                contato@senhorespetto.com.br
              </p>
              <p className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-amber-500" />
                Rua dos Espetos, 123 • São Paulo
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-amber-500 mb-4">Horário</h3>
            <div className="space-y-2">
              <p>Terça a Quinta: 18h às 00h</p>
              <p>Sexta e Sábado: 18h às 02h</p>
              <p>Domingo: 17h às 23h</p>
              <p>Segunda: Fechado</p>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-stone-800">
          <div className="flex justify-center space-x-6">
            <SocialLink href="#" icon={<Instagram className="w-6 h-6" />} />
            <SocialLink href="#" icon={<Facebook className="w-6 h-6" />} />
          </div>
          <div className="mt-8 text-center text-sm">
            <p>&copy; 2024 Senhor Espetto. Todos os direitos reservados.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

const SocialLink = ({ href, icon }: { href: string; icon: React.ReactNode }) => (
  <a
    href={href}
    className="text-amber-500 hover:text-amber-400 transition-colors"
  >
    {icon}
  </a>
);