import React from 'react';
import { menuItems } from '../data/menu';

export const MenuSection = () => {
  return (
    <section id="menu" className="py-20 bg-stone-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-serif font-bold text-amber-500 text-center mb-16">
          Nossas Cervejas
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems.map((item) => (
            <div key={item.name} className="bg-stone-800 rounded-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-amber-500 mb-2">
                  {item.name}
                </h3>
                <p className="text-stone-300 mb-4">{item.description}</p>
                <div className="space-y-1">
                  {item.ingredients.map((ingredient, index) => (
                    <p key={index} className="text-sm text-stone-400">
                      • {ingredient}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};