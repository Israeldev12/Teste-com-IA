import React from 'react';
import { Logo } from './Logo';
import { Menu } from 'lucide-react';

export const Navbar = () => {
  return (
    <nav className="fixed w-full bg-stone-900/95 backdrop-blur-sm z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Logo />
          <div className="hidden md:flex space-x-8">
            <NavLink href="#menu">Menu</NavLink>
            <NavLink href="#ambiente">Ambiente</NavLink>
            <NavLink href="#sobre">Sobre</NavLink>
            <NavLink href="#contato">Contato</NavLink>
          </div>
          <button className="p-2 text-amber-700 hover:bg-stone-800 rounded-full md:hidden">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>
    </nav>
  );
};

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <a
    href={href}
    className="text-amber-500 hover:text-amber-400 transition-colors font-medium"
  >
    {children}
  </a>
);