import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { Ambiente } from './components/Ambiente';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-stone-900 text-white">
      <Navbar />
      <Hero />
      <MenuSection />
      <Ambiente />
      <Footer />
    </div>
  );
}

export default App;