export const menuItems = [
  {
    name: 'Heineken',
    image: 'https://images.unsplash.com/photo-1618885472179-5e474019f2a9?auto=format&fit=crop&q=80',
    description: 'Cerveja premium holandesa, conhecida pelo seu sabor equilibrado e refrescante.',
    ingredients: [
      'Teor alcoólico: 5%',
      'Origem: Holanda',
      'Tipo: Lager Premium'
    ]
  },
  {
    name: 'Stella Artois',
    image: 'https://images.unsplash.com/photo-1608270586620-248524c67de9?auto=format&fit=crop&q=80',
    description: 'Cerveja belgian lager com tradição desde 1366.',
    ingredients: [
      'Teor alcoólico: 5%',
      'Origem: Bélgica',
      'Tipo: Premium Lager'
    ]
  },
  {
    name: 'Spaten',
    image: 'https://images.unsplash.com/photo-1571613316887-6f8d5cbf7ef7?auto=format&fit=crop&q=80',
    description: 'Cerveja alemã premium, produzida segundo a lei de pureza.',
    ingredients: [
      'Teor alcoólico: 5.2%',
      'Origem: Alemanha',
      'Tipo: Munich Helles Lager'
    ]
  },
  {
    name: 'Brahma',
    image: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?auto=format&fit=crop&q=80',
    description: 'Cerveja brasileira refrescante e popular.',
    ingredients: [
      'Teor alcoólico: 4.8%',
      'Origem: Brasil',
      'Tipo: American Lager'
    ]
  },
  {
    name: 'Original',
    image: 'https://images.unsplash.com/photo-1584225064785-c62a8b43d148?auto=format&fit=crop&q=80',
    description: 'Cerveja brasileira com receita original desde 1931.',
    ingredients: [
      'Teor alcoólico: 5%',
      'Origem: Brasil',
      'Tipo: Standard American Lager'
    ]
  },
  {
    name: 'Skol',
    image: 'https://images.unsplash.com/photo-1586993451228-09818021e309?auto=format&fit=crop&q=80',
    description: 'Cerveja leve e refrescante, ideal para momentos descontraídos.',
    ingredients: [
      'Teor alcoólico: 4.7%',
      'Origem: Brasil',
      'Tipo: American Lager'
    ]
  }
];