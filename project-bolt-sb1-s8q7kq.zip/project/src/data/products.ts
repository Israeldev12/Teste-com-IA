export const products = [
  {
    name: 'Peteca Profissional',
    image: 'https://images.unsplash.com/photo-1610736342165-4efd4c50bd7c?auto=format&fit=crop&q=80&w=800',
    description: 'Peteca oficial para competições, com base em couro e penas selecionadas.',
    details: [
      'Base em couro legítimo',
      'Penas naturais selecionadas',
      'Peso oficial de competição',
      'Certificada para torneios'
    ]
  },
  {
    name: 'Peteca Recreativa',
    image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&q=80&w=800',
    description: 'Ideal para diversão em família, resistente e leve.',
    details: [
      'Base em material sintético durável',
      'Penas sintéticas resistentes',
      'Peso intermediário',
      'Ideal para lazer'
    ]
  },
  {
    name: 'Peteca Infantil',
    image: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&q=80&w=800',
    description: 'Desenvolvida especialmente para crianças, com materiais seguros.',
    details: [
      'Material ultra leve',
      'Base acolchoada',
      'Penas coloridas',
      'Segura para crianças'
    ]
  }
];